package com.example.shark

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.tts.TextToSpeech
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

/** منبهات "شارك": بتتخزن وبتتظبط على AlarmManager، وبترجع تتظبط بعد إعادة تشغيل الموبايل. */
object WakeAlarms {
    private const val PREF = "wake_alarms"

    fun schedule(ctx: Context, at: Long, name: String, label: String) {
        val arr = load(ctx)
        arr.put(JSONObject().put("at", at).put("name", name).put("label", label))
        save(ctx, arr)
        setOne(ctx, at, name, label)
    }

    fun setOne(ctx: Context, at: Long, name: String, label: String) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val fire = PendingIntent.getBroadcast(
            ctx, (at / 1000).toInt(),
            Intent(ctx, WakeReceiver::class.java).putExtra("at", at).putExtra("name", name).putExtra("label", label),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val show = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), fire)
    }

    fun remove(ctx: Context, at: Long) {
        val arr = load(ctx)
        val out = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.getLong("at") != at) out.put(o)
        }
        save(ctx, out)
    }

    fun rescheduleAll(ctx: Context) {
        val arr = load(ctx)
        val out = JSONArray()
        val now = System.currentTimeMillis()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.getLong("at") > now) {
                out.put(o)
                setOne(ctx, o.getLong("at"), o.optString("name"), o.optString("label"))
            }
        }
        save(ctx, out)
    }

    private fun load(ctx: Context): JSONArray = try {
        JSONArray(ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("list", "[]"))
    } catch (e: Exception) { JSONArray() }

    private fun save(ctx: Context, a: JSONArray) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("list", a.toString()).apply()
    }
}

class WakeReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        val at = i.getLongExtra("at", 0L)
        WakeAlarms.remove(ctx, at)
        val s = Intent(ctx, WakeService::class.java)
            .putExtra("name", i.getStringExtra("name") ?: "")
            .putExtra("label", i.getStringExtra("label") ?: "")
        try { ContextCompat.startForegroundService(ctx, s) } catch (e: Exception) { }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) WakeAlarms.rescheduleAll(ctx)
    }
}

/** لما المنبه يرن: بيعلّي صوت المنبه، وينده باسمك بصوت عالي كل كام ثانية، ويرن ويهتز لحد ما تقول إنك صحيت. */
class WakeService : Service() {
    companion object {
        const val STOP = "com.example.shark.WAKE_STOP"
        const val SNOOZE = "com.example.shark.WAKE_SNOOZE"
        const val CHANNEL = "shark_wake"
        @Volatile var active = false
    }

    private val h = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ring: Ringtone? = null
    private var vib: Vibrator? = null
    private var wake: PowerManager.WakeLock? = null
    private var prevVol = -1
    private var n = 0
    private var name = ""
    private var label = ""
    private var started = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            STOP -> { finish(); return START_NOT_STICKY }
            SNOOZE -> {
                val nm = intent?.getStringExtra("name") ?: name
                val lb = intent?.getStringExtra("label") ?: label
                WakeAlarms.schedule(this, System.currentTimeMillis() + 5 * 60_000L, nm, lb)
                finish()
                return START_NOT_STICKY
            }
        }
        if (started) return START_NOT_STICKY
        started = true
        active = true
        name = intent?.getStringExtra("name") ?: ""
        label = intent?.getStringExtra("label") ?: ""

        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "منبه شارك", NotificationManager.IMPORTANCE_HIGH))
        val stop = PendingIntent.getService(
            this, 1, Intent(this, WakeService::class.java).setAction(STOP), PendingIntent.FLAG_IMMUTABLE)
        val snooze = PendingIntent.getService(
            this, 2,
            Intent(this, WakeService::class.java).setAction(SNOOZE).putExtra("name", name).putExtra("label", label),
            PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 3, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val notif = Notification.Builder(this, CHANNEL)
            .setContentTitle("اصحى" + (if (name.isBlank()) "" else " يا $name") + "!")
            .setContentText(if (label.isBlank()) "المنبه شغّال" else label)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(0, "صحيت", stop).build())
            .addAction(Notification.Action.Builder(0, "5 دقايق كمان", snooze).build())
            .build()
        try {
            ServiceCompat.startForeground(this, 2, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } catch (e: Exception) {
            finish()
            return START_NOT_STICKY
        }

        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "shark:wake").apply { acquire(11 * 60_000L) }
        } catch (e: Exception) { }
        try {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            prevVol = am.getStreamVolume(AudioManager.STREAM_ALARM)
            am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
        } catch (e: Exception) { }
        try {
            vib = getSystemService(VIBRATOR_SERVICE) as Vibrator
            vib?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 700, 400), 0))
        } catch (e: Exception) { }

        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.let { t ->
                    t.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build())
                    if (t.setLanguage(Locale("ar", "EG")) < 0) t.setLanguage(Locale("ar"))
                    try {
                        val saved = getSharedPreferences("shark", MODE_PRIVATE).getString("voice", null)
                        t.voices?.firstOrNull { it.name == saved }?.let { t.setVoice(it) }
                    } catch (e: Exception) { }
                    t.setSpeechRate(getSharedPreferences("shark", MODE_PRIVATE).getFloat("rate", 1.0f))
                    ttsReady = true
                }
            }
        }
        h.post(tick)
        return START_NOT_STICKY
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!active) return
            if (n >= 100) { finish(); return }   // بعد حوالي 10 دقايق بيقف لوحده
            if (ttsReady) speakNow()
            if (n == 4) startRing()
            n++
            h.postDelayed(this, 6000)
        }
    }

    private fun speakNow() {
        val who = if (name.isBlank()) "" else " يا $name"
        val c = Calendar.getInstance()
        val hh = (c.get(Calendar.HOUR)).let { if (it == 0) 12 else it }
        val mm = c.get(Calendar.MINUTE)
        val timeTxt = "الساعة $hh" + (if (mm > 0) " و$mm دقيقة" else "")
        val msg = when {
            n == 0 -> "صباح الخير$who! اصحى، $timeTxt." + (if (label.isBlank()) "" else " $label")
            n % 3 == 0 -> "قوم$who! يلا، متتأخرش"
            else -> "اصحى بقى$who!"
        }
        tts?.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "wake")
    }

    private fun startRing() {
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            val r = RingtoneManager.getRingtone(this, uri)
            r.audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            if (Build.VERSION.SDK_INT >= 28) r.isLooping = true
            r.play()
            ring = r
        } catch (e: Exception) { }
    }

    private fun finish() {
        active = false
        h.removeCallbacksAndMessages(null)
        try { ring?.stop() } catch (e: Exception) { }
        ring = null
        try { tts?.stop(); tts?.shutdown() } catch (e: Exception) { }
        tts = null
        try { vib?.cancel() } catch (e: Exception) { }
        try {
            if (prevVol >= 0) {
                val am = getSystemService(AUDIO_SERVICE) as AudioManager
                am.setStreamVolume(AudioManager.STREAM_ALARM, prevVol, 0)
            }
        } catch (e: Exception) { }
        try { wake?.takeIf { it.isHeld }?.release() } catch (e: Exception) { }
        wake = null
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (e: Exception) { }
        stopSelf()
    }

    override fun onDestroy() {
        if (active) finish()
        super.onDestroy()
    }
}
