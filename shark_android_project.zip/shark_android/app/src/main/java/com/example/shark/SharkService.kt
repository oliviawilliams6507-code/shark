package com.example.shark

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.IBinder
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.core.app.ServiceCompat

/** خدمة أمامية (إشعار دايم) بتخلّي التطبيق والمايك شغّالين حتى لو الشاشة اتقفلت. */
class SharkService : Service() {
    companion object {
        const val ACTION_STOP = "com.example.shark.STOP"
        const val CHANNEL = "shark_listen"
        @Volatile var onStopRequested: (() -> Unit)? = null
    }

    private var wake: PowerManager.WakeLock? = null
    private var overlay: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            onStopRequested?.invoke()
            stopSelf()
            return START_NOT_STICKY
        }
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "شارك شغّال", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, SharkService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("شارك شغّال")
            .setContentText("قول «شارك» وبعدين أي أمر")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(0, "إيقاف", stop).build())
            .build()
        try {
            ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (wake == null) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "shark:listen").apply {
                setReferenceCounted(false)
                acquire()
            }
        }
        // نافذة شفافة 1px: بتخلّي أندرويد يسمح للتطبيق يفتح تطبيقات وهو في الخلفية (لو إذن العرض فوق التطبيقات متفعّل)
        if (overlay == null && Settings.canDrawOverlays(this)) {
            try {
                val wm = getSystemService(WINDOW_SERVICE) as WindowManager
                val v = View(this)
                val lp = WindowManager.LayoutParams(
                    1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT
                )
                lp.gravity = Gravity.TOP or Gravity.START
                wm.addView(v, lp)
                overlay = v
            } catch (e: Exception) { }
        }
        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        stopSelf()   // لو الشاشة اتشالت من الأخيرة (swipe) الخدمة ملهاش لازمة
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        try { overlay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } } catch (e: Exception) { }
        overlay = null
        try { wake?.takeIf { it.isHeld }?.release() } catch (e: Exception) { }
        wake = null
        super.onDestroy()
    }
}
