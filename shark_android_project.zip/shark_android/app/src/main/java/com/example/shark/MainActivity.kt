package com.example.shark  // غيّره لاسم الـ package بتاع مشروعك

import android.Manifest
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.OnBackPressedCallback
import android.provider.AlarmClock
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.MediaStore
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var paused = false
    private var keep = false          // شغّال في الخلفية (الخدمة شغالة)
    private var wantListen = false    // الـ JS عايز استماع
    private val handler = Handler(Looper.getMainLooper())
    private var afterUnlock: Intent? = null
    private var unlockRegistered = false
    private val unlockRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val x = afterUnlock
            afterUnlock = null
            if (unlockRegistered) { try { unregisterReceiver(this) } catch (e: Exception) { }; unlockRegistered = false }
            if (x != null) try { startActivity(x) } catch (e: Exception) { }
        }
    }

    // launcher واحد بنستخدمه لكل الأذونات (مايك، جهات اتصال، اتصال)
    private val askPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val recIntent by lazy {
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-EG")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)   // بيرجّع أكتر من احتمال للجملة عشان نفهم أدق
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        askPerm.launch(Manifest.permission.RECORD_AUDIO)   // أول تشغيل: بيطلب إذن المايك
        SharkService.onStopRequested = { keep = false; js("stop()") }   // زرار "إيقاف" في الإشعار
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (keep) moveTaskToBack(true)   // يفضل شغّال في الخلفية
                else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })

        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webChromeClient = WebChromeClient()
        if (Build.VERSION.SDK_INT >= 26) web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val url = r.url.toString()
                if (url.startsWith("file:")) return false
                launch(url)
                return true
            }
        }
        web.addJavascriptInterface(Bridge(), "Android")

        tts = TextToSpeech(this) { st -> if (st == TextToSpeech.SUCCESS) pickArabicVoice() }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) = js("onNativeSpeakDone()")
            @Deprecated("") override fun onError(id: String?) = js("onNativeSpeakDone()")
        })

        if (!SpeechRecognizer.isRecognitionAvailable(this))
            Toast.makeText(this, "جهازك مفيهوش خدمة التعرف على الكلام (Google)", Toast.LENGTH_LONG).show()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) {
                    listening = false
                    val list = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.filter { it.isNotBlank() }
                    if (list.isNullOrEmpty()) js("onNativeError()")
                    else js("onNativeResult(${JSONObject.quote(list[0])}, ${JSONArray(list)})")
                    scheduleRestart(1500)
                }
                override fun onError(e: Int) {
                    listening = false
                    if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { wantListen = false; return }
                    js("onNativeError()")
                    scheduleRestart(1200)
                }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(r: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
        }
        web.loadUrl("file:///android_asset/shark.html")
    }

    /** بيدوّر على أحسن صوت عربي: مصري محلي، وبعدين أي مصري، وبعدين أي عربي. */
    private fun pickArabicVoice() {
        if (tts.setLanguage(Locale("ar", "EG")) < 0) tts.setLanguage(Locale("ar"))
        try {
            val ar = (tts.voices ?: emptySet()).filter { it.locale.language == "ar" }
            val best = ar.firstOrNull { it.locale.country == "EG" && !it.isNetworkConnectionRequired }
                ?: ar.firstOrNull { it.locale.country == "EG" }
                ?: ar.firstOrNull { !it.isNetworkConnectionRequired }
                ?: ar.firstOrNull()
            val prefs = getSharedPreferences("shark", MODE_PRIVATE)
            val chosen = ar.firstOrNull { it.name == prefs.getString("voice", null) } ?: best
            if (chosen != null) tts.setVoice(chosen)
        } catch (e: Exception) { }
        tts.setSpeechRate(getSharedPreferences("shark", MODE_PRIVATE).getFloat("rate", 1.0f))
    }

    override fun onPause() {
        super.onPause()
        paused = true
        if (!keep) {   // لو مفيش تشغيل في الخلفية، بنوقف المايك زي الأول
            listening = false
            recognizer?.cancel()
            tts.stop()
        }
    }

    override fun onResume() {
        super.onResume()
        paused = false
        if (keep) {
            askBackgroundSetup()
            try { ContextCompat.startForegroundService(this, Intent(this, SharkService::class.java)) } catch (e: Exception) { }
        }
        js("onNativeSpeakDone()")   // يصفّر حالة الكلام ويرجّع الاستماع لو كان شغال
    }

    override fun onDestroy() {
        keep = false
        wantListen = false
        SharkService.onStopRequested = null
        stopService(Intent(this, SharkService::class.java))
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        tts.shutdown()
        super.onDestroy()
    }

    private fun canListen() = wantListen && !listening && !tts.isSpeaking && (!paused || keep)

    private fun startRec() {
        if (!canListen()) return
        listening = true
        try { recognizer?.startListening(recIntent) } catch (e: Exception) { listening = false }
    }

    /** لو الـ JS ماطلبش استماع جديد (مثلاً الصفحة في الخلفية)، بنرجّع الاستماع من هنا. */
    private fun scheduleRestart(delayMs: Long) {
        handler.postDelayed({ startRec() }, delayMs)
    }

    private fun setKeep(on: Boolean) {
        keep = on
        val i = Intent(this, SharkService::class.java)
        if (on) {
            if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS))
                askPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
            try { ContextCompat.startForegroundService(this, i) }
            catch (e: Exception) { keep = false; Toast.makeText(this, "مقدرتش أشغّل التشغيل في الخلفية", Toast.LENGTH_LONG).show() }
            askBackgroundSetup()
        } else stopService(i)
    }

    /** أذونات الخلفية: "العرض فوق التطبيقات" (عشان يفتح تطبيقات وهو في الخلفية) وبعدها استثناء البطارية. بتتسأل مرة واحدة بس. */
    private fun askBackgroundSetup() {
        val prefs = getSharedPreferences("shark", MODE_PRIVATE)
        try {
            if (!Settings.canDrawOverlays(this) && !prefs.getBoolean("askedOverlay", false)) {
                prefs.edit().putBoolean("askedOverlay", true).apply()
                Toast.makeText(this, "فعّل «العرض فوق التطبيقات» لشارك، وارجع", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                return
            }
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName) && !prefs.getBoolean("askedBattery", false)) {
                prefs.edit().putBoolean("askedBattery", true).apply()
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            }
        } catch (e: Exception) { }
    }

    private fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }

    private fun has(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    /** بيشغّل الـ Intent على الـ UI thread وبيرجّع true لو اتفتح فعلاً (من غير exception). */
    private fun startSafe(i: Intent): Boolean {
        var ok = false
        val latch = CountDownLatch(1)
        runOnUiThread {
            ok = try { startActivity(i); true } catch (e: Exception) { false }
            latch.countDown()
        }
        latch.await(2, TimeUnit.SECONDS)
        return ok
    }

    /** يفتح رابط عادي أو intent: (تطبيق أو إعدادات) ويرجّع هل نجح. */
    private fun launch(url: String): Boolean {
        if (url.startsWith("file:")) return false
        return try {
            if (url.startsWith("intent:")) {
                val i = Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                i.component = null   // أمان: الصفحة متقدرش تستهدف component بعينه
                i.selector = null
                val pkg = i.`package`
                val launchIntent = if (pkg != null && url.startsWith("intent://#")) packageManager.getLaunchIntentForPackage(pkg) else null
                if (startSafe(launchIntent ?: i)) true
                else i.getStringExtra("browser_fallback_url")?.let { startSafe(Intent(Intent.ACTION_VIEW, Uri.parse(it))) } ?: false
            } else startSafe(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) { false }
    }

    private fun normAr(s: String): String = s.lowercase(Locale.ROOT)
        .replace(Regex("[أإآ]"), "ا").replace('ة', 'ه').replace('ى', 'ي')
        .replace(Regex("[\u064B-\u0652]"), "")
        .replace(Regex("\\s+"), " ").trim()

    /** بحث في جهات الاتصال بالاسم (بتطبيع عربي)، بيرجّع JSON array فيها {name, number} بحد أقصى 5. */
    private fun searchContacts(q: String): String {
        val nq = normAr(q)
        val out = JSONArray()
        if (nq.isEmpty()) return out.toString()
        val found = ArrayList<Triple<Int, String, String>>()
        val seen = HashSet<String>()
        contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(0) ?: continue
                val num = c.getString(1) ?: continue
                val nn = normAr(name)
                if (!nn.contains(nq)) continue
                if (!seen.add(num.filter { it.isDigit() })) continue
                val rank = if (nn == nq) 0 else if (nn.startsWith(nq)) 1 else 2
                found.add(Triple(rank, name, num))
            }
        }
        found.sortedBy { it.first }.take(5).forEach { out.put(JSONObject().put("name", it.second).put("number", it.third)) }
        return out.toString()
    }

    /* ===== البحث عن أي تطبيق منزّل بالاسم (عربي أو إنجليزي) ===== */

    /** كل التطبيقات اللي ليها أيقونة في الشاشة: (الاسم، الـ package) */
    private fun launcherApps(): List<Pair<String, String>> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(i, 0)
            .map { Pair(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
            .filter { it.second != packageName }
            .distinctBy { it.second }
    }

    /** بصمة صوتية: الحروف الساكنة بس (عشان "انستجرام" تطابق "Instagram")؛ vow=true بيحتفظ بتصنيف الحروف المتحركة. */
    private fun skel(s: String, chS: Boolean = false, vow: Boolean = false): String {
        val t = normAr(s)
        val out = StringBuilder()
        fun add(c: Char) { if (out.isEmpty() || out[out.length - 1] != c) out.append(c) }
        var prev = ' '
        for (i in t.indices) {
            val c = t[i]
            val nx = if (i + 1 < t.length) t[i + 1] else ' '
            when (c) {
                'ب', 'p', 'b' -> add('P')
                'ت', 'ط', 't' -> add('T')
                'ث', 'س', 'ص', 'ز', 'ظ', 'ذ', 'ش', 's', 'z' -> add('S')
                'ج', 'غ', 'j', 'g' -> add('J')
                'ح', 'ه' -> add('H')
                'خ', 'ق', 'ك', 'k', 'q' -> add('K')
                'د', 'ض', 'd' -> add('D')
                'ر', 'r' -> add('R')
                'ف', 'f', 'v' -> add('F')
                'ل', 'l' -> add('L')
                'م', 'm' -> add('M')
                'ن', 'n' -> add('N')
                'ا', 'a' -> if (vow) add('A')
                'و', 'o', 'u', 'w' -> if (vow) add('U')
                'ي', 'e', 'i', 'y' -> if (vow) add('I')
                'h' -> if ("cstpkgwd".indexOf(prev) < 0) add('H')
                'c' -> add(if ("eiy".indexOf(nx) >= 0 || (chS && nx == 'h')) 'S' else 'K')
                'x' -> { add('K'); add('S') }
                in '0'..'9' -> add(c)
                else -> { }
            }
            prev = c
        }
        return out.toString()
    }

    private fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val p = d.copyOf()
            d[0] = i
            for (j in 1..b.length)
                d[j] = minOf(p[j] + 1, d[j - 1] + 1, p[j - 1] + (if (a[i - 1] == b[j - 1]) 0 else 1))
        }
        return d[b.length]
    }

    private fun baseScore(q: String, label: String): Int {
        val nq = normAr(q).replace(" ", "")
        val nl = normAr(label).replace(Regex("[^\\p{L}\\p{N}]"), "")
        if (nq.isEmpty() || nl.isEmpty()) return 0
        if (nl == nq) return 100
        if (nq.length >= 3 && nl.startsWith(nq)) return 85
        if (nq.length >= 3 && nl.contains(nq)) return 70
        val sq = skel(q)
        var best = 0
        for (chS in listOf(false, true)) {
            val sl = skel(label, chS)
            if (sl.isEmpty()) continue
            val s = when {
                sq == sl && (sq.length >= 2 || nq.length >= 3) -> 90
                sq.length >= 3 && sl.startsWith(sq) -> 75
                sq.length >= 3 && sl.contains(sq) -> 60
                sl.length >= 3 && sq.contains(sl) -> 55
                else -> 0
            }
            if (s > best) best = s
        }
        return best
    }

    private fun appScore(q: String, label: String): Int {
        val nq = normAr(q)
        val cands = if (nq.startsWith("ال") && nq.length > 3) listOf(q, nq.substring(2)) else listOf(q)
        var bestC = cands[0]
        var b = 0
        for (c in cands) { val s = baseScore(c, label); if (s > b) { b = s; bestC = c } }
        if (b == 0) return 0
        val d = minOf(lev(skel(bestC, false, true), skel(label, false, true)), 5)
        return b - d * 3
    }

    inner class Bridge {
        @JavascriptInterface fun speak(t: String) = runOnUiThread {
            recognizer?.cancel(); listening = false
            tts.speak(t.take(3900), TextToSpeech.QUEUE_FLUSH, null, "u")
        }
        @JavascriptInterface fun listen() = runOnUiThread {
            wantListen = true
            startRec()
        }
        @JavascriptInterface fun stopAll() = runOnUiThread {
            wantListen = false
            recognizer?.cancel(); tts.stop(); listening = false
        }
        @JavascriptInterface fun isLocked(): Boolean =
            (getSystemService(KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked

        /** الفون مقفول: يحفظ التطبيق ويفتحه أول ما القفل يتفك. */
        @JavascriptInterface fun openAfterUnlock(pkg: String) = runOnUiThread {
            val i = packageManager.getLaunchIntentForPackage(pkg) ?: return@runOnUiThread
            afterUnlock = i
            if (!unlockRegistered) {
                ContextCompat.registerReceiver(this@MainActivity, unlockRx, IntentFilter(Intent.ACTION_USER_PRESENT), ContextCompat.RECEIVER_NOT_EXPORTED)
                unlockRegistered = true
            }
        }
        /** الأصوات العربي المتاحة على الجهاز (JSON). */
        @JavascriptInterface fun voices(): String {
            val arr = JSONArray()
            try {
                (tts.voices ?: emptySet()).filter { it.locale.language == "ar" }.sortedBy { it.name }.forEach { v ->
                    arr.put(JSONObject().put("name", v.name).put("c", v.locale.country).put("net", v.isNetworkConnectionRequired))
                }
            } catch (e: Exception) { }
            return arr.toString()
        }
        @JavascriptInterface fun setVoice(name: String): Boolean {
            return try {
                val v = tts.voices?.firstOrNull { it.name == name } ?: return false
                tts.setVoice(v)
                getSharedPreferences("shark", MODE_PRIVATE).edit().putString("voice", name).apply()
                true
            } catch (e: Exception) { false }
        }
        @JavascriptInterface fun setRate(r: Double) {
            val f = r.toFloat().coerceIn(0.5f, 2.0f)
            tts.setSpeechRate(f)
            getSharedPreferences("shark", MODE_PRIVATE).edit().putFloat("rate", f).apply()
        }
        /** سجل المكالمات: "NOPERM" أو JSON [{name,number}]. q فاضي = آخر المكالمات. */
        @JavascriptInterface fun findCallLog(q: String): String {
            if (!has(Manifest.permission.READ_CALL_LOG)) {
                runOnUiThread { askPerm.launch(Manifest.permission.READ_CALL_LOG) }
                return "NOPERM"
            }
            val out = JSONArray()
            val seen = HashSet<String>()
            try {
                contentResolver.query(
                    CallLog.Calls.CONTENT_URI,
                    arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME),
                    null, null, CallLog.Calls.DATE + " DESC"
                )?.use { c ->
                    val qq = normAr(q)
                    while (c.moveToNext() && out.length() < 5) {
                        val num = c.getString(0) ?: continue
                        val nm = c.getString(1) ?: ""
                        if (num.isBlank() || !seen.add(num)) continue
                        if (qq.isEmpty() || normAr(nm).contains(qq) || normAr(num).contains(qq)) {
                            out.put(JSONObject().put("name", if (nm.isBlank()) num else nm).put("number", num))
                        }
                    }
                }
            } catch (e: Exception) { }
            return out.toString()
        }

        /** منبه بصوت شارك: بيصحيك باسمك. "OK" أو "FAIL". */
        @JavascriptInterface fun scheduleWakeAt(h: Int, m: Int, name: String, label: String): String {
            val c = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            if (c.timeInMillis <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_MONTH, 1)
            return scheduleWakeMs(c.timeInMillis, name, label)
        }
        @JavascriptInterface fun scheduleWakeIn(seconds: Int, name: String, label: String): String =
            scheduleWakeMs(System.currentTimeMillis() + seconds * 1000L, name, label)

        private fun scheduleWakeMs(at: Long, name: String, label: String): String {
            return try {
                WakeAlarms.schedule(this@MainActivity, at, name, label)
                if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) {
                    runOnUiThread { askPerm.launch(Manifest.permission.POST_NOTIFICATIONS) }
                }
                "OK"
            } catch (e: Exception) { "FAIL" }
        }
        @JavascriptInterface fun wakeActive(): Boolean = WakeService.active
        @JavascriptInterface fun stopWake() {
            try { startService(Intent(this@MainActivity, WakeService::class.java).setAction(WakeService.STOP)) } catch (e: Exception) { }
        }
        @JavascriptInterface fun keepAlive(on: Boolean) = runOnUiThread { setKeep(on) }

        @JavascriptInterface fun openUri(url: String): Boolean = launch(url)

        /** أحسن 3 تطبيقات منزّلة مطابقة للاسم: JSON array فيها {score, label, pkg}. */
        @JavascriptInterface fun findApp(q: String): String {
            val out = JSONArray()
            try {
                launcherApps()
                    .map { Triple(appScore(q, it.first), it.first, it.second) }
                    .filter { it.first > 0 }
                    .sortedByDescending { it.first }
                    .take(3)
                    .forEach { out.put(JSONObject().put("score", it.first).put("label", it.second).put("pkg", it.third)) }
            } catch (e: Exception) { }
            return out.toString()
        }

        @JavascriptInterface fun launchPackage(pkg: String): Boolean {
            val i = packageManager.getLaunchIntentForPackage(pkg) ?: return false
            return startSafe(i)
        }

        /** "NOPERM" لو مفيش إذن (وبيطلبه)، وإلا JSON array. */
        @JavascriptInterface fun findContact(q: String): String {
            if (!has(Manifest.permission.READ_CONTACTS)) {
                runOnUiThread { askPerm.launch(Manifest.permission.READ_CONTACTS) }
                return "NOPERM"
            }
            return try { searchContacts(q) } catch (e: Exception) { "[]" }
        }

        /** "OK" | "NOPERM" | "FAIL". الاتصال المباشر بيحتاج إذن CALL_PHONE. */
        @JavascriptInterface fun call(number: String): String {
            if (!has(Manifest.permission.CALL_PHONE)) {
                runOnUiThread { askPerm.launch(Manifest.permission.CALL_PHONE) }
                return "NOPERM"
            }
            val n = number.filter { it.isDigit() || it == '+' }
            return if (startSafe(Intent(Intent.ACTION_CALL, Uri.parse("tel:$n")))) "OK" else "FAIL"
        }

        /** بيجهّز الرسالة في تطبيق الرسايل، والمستخدم هو اللي بيدوس إرسال. */
        @JavascriptInterface fun sms(number: String, text: String): Boolean {
            val n = number.filter { it.isDigit() || it == '+' }
            return startSafe(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$n")).putExtra("sms_body", text))
        }

        @JavascriptInterface fun setAlarm(h: Int, m: Int, label: String): Boolean = startSafe(
            Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, h)
                .putExtra(AlarmClock.EXTRA_MINUTES, m)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )

        @JavascriptInterface fun setTimer(seconds: Int, label: String): Boolean = startSafe(
            Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )

        @JavascriptInterface fun camera(): Boolean = startSafe(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))

        @JavascriptInterface fun battery(): Int =
            (getSystemService(BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)

        @JavascriptInterface fun closeApp() = runOnUiThread { finishAffinity() }
    }

}
